"""
Missionaries and Cannibals by Michał Żelazko CS2 242149
Three missionaries and three cannibals on left bank of the river
Game's objective is to move them to the right bank of the river
Boat can transport either 1 or 2 characters at a time
If cannibals outnumber missionaries on a bank of the river - you lose
"""
import sys
import pygame

RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
LIGHT_GREY = (192, 192, 192)


def rules_controls(scr, window, back_btn):
    """
    Displaying rules and controls of the game.
    Click BACK to get back to main menu.
    """
    pygame.init()
    fpsClock = pygame.time.Clock()
    myfont = pygame.font.Font('algerian.ttf', 20)
    myfontbig = pygame.font.Font('algerian.ttf', 50)
    controls = myfontbig.render("CONTROLS", True, (BLACK), (None))
    controls_box = controls.get_rect()
    controls_box.center = (scr.width/2, scr.height/10)
    ctrl1 = myfont.render("1. Click on a character to move it aboard",
                          True, (BLACK), (None))
    ctrl1_box = ctrl1.get_rect()
    ctrl1_box.center = (scr.width/2, 2 * scr.height/10)
    ctrl2 = myfont.render("2. Click on the boat " +
                          "to transport characters to other bank of the river",
                          True, (BLACK), (None))
    ctrl2_box = ctrl2.get_rect()
    ctrl2_box.center = (scr.width/2, 3 * scr.height/10)
    ctrl3 = myfont.render("3. Click 'Empty the boat'" +
                          "button on the bottom " +
                          "of the screen to empty the boat",
                          True, (BLACK), (None))
    ctrl3_box = ctrl3.get_rect()
    ctrl3_box.center = (scr.width/2, 4 * scr.height/10)
    rules = myfontbig.render("RULES", True, (BLACK), (None))
    rules_box = rules.get_rect()
    rules_box.center = (scr.width/2, scr.height/2)
    rule1 = myfont.render("1. The goal of the game is to " +
                          "move all characters to the" +
                          " right bank of the river",
                          True, (BLACK), (None))
    rule1_box = rule1.get_rect()
    rule1_box.center = (scr.width/2, 6 * scr.height/10)
    rule2 = myfont.render("2. Boat can be moved" +
                          " with 1 or 2 characters aboard",
                          True, (BLACK), (None))
    rule2_box = rule2.get_rect()
    rule2_box.center = (scr.width/2, 7 * scr.height/10)
    rule3 = myfont.render("3. Cannibals can't outnumber " +
                          "missionaries on either side -" +
                          " if they do, you lose.",
                          True, (BLACK), (None))
    rule3_box = rule3.get_rect()
    rule3_box.center = (scr.width/2, 8 * scr.height/10)
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    sys.exit()
            if event.type == pygame.MOUSEBUTTONUP:
                if back_btn["rect"].collidepoint(pygame.mouse.get_pos()):
                    menu()
        window.fill(LIGHT_GREY)
        window.blit(back_btn["surf"], back_btn["rect"])
        window.blit(controls, controls_box)
        window.blit(ctrl1, ctrl1_box)
        window.blit(ctrl2, ctrl2_box)
        window.blit(ctrl3, ctrl3_box)
        window.blit(rules, rules_box)
        window.blit(rule1, rule1_box)
        window.blit(rule2, rule2_box)
        window.blit(rule3, rule3_box)
        fpsClock.tick(120)
        pygame.display.update()


def menu():
    """
    Main menu where a player can choose whether he wants to
    start a new game, get to know rules and controls of the game
    or exit the game. Program responds when button is clicked.
    """
    pygame.init()
    window = pygame.display.set_mode((900, 900))
    scr = window.get_rect()
    fpsClock = pygame.time.Clock()
    background = pygame.image.load("bg.png").convert()

    start_btn = {"file": "start_button.png"}
    rules_controls_btn = {"file": "rules_controls_button.png"}
    exit_btn = {"file": "exit_button.png"}
    back_btn = {"file": "back_button.png"}

    btns = [start_btn, rules_controls_btn, exit_btn]

    for i, btn in enumerate(btns):
        btn["surf"] = pygame.image.load(btn["file"])
        btn["rect"] = btn["surf"].get_rect()
        btn["rect"].center = (scr.width/2, (i + 2)*scr.height/5)

    back_btn["surf"] = pygame.image.load(back_btn["file"])
    back_btn["rect"] = btn["surf"].get_rect()
    back_btn["rect"].midbottom = (scr.width/2, scr.height - 20)

    myfontbig = pygame.font.Font('algerian.ttf', 60)
    header = myfontbig.render("MISSIONARIES&CANNIBALS", True, (BLACK), (None))
    header_box = header.get_rect()
    header_box.center = (scr.width/2, scr.height/5)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    sys.exit()
            if event.type == pygame.MOUSEBUTTONUP:
                if start_btn["rect"].collidepoint(pygame.mouse.get_pos()):
                    main_game_loop(scr, window)
                if rules_controls_btn["rect"].\
                   collidepoint(pygame.mouse.get_pos()):
                    rules_controls(scr, window, back_btn)
                if exit_btn["rect"].collidepoint(pygame.mouse.get_pos()):
                    sys.exit()
        window.fill(LIGHT_GREY)
        window.blit(header, header_box)
        for btn in btns:
            window.blit(btn["surf"], btn["rect"])
        fpsClock.tick(120)
        pygame.display.update()


def failure(scr, window):
    """
    Displaying information that you lost the game.
    Enables to play again or exit the game.
    """
    pygame.init()
    fpsClock = pygame.time.Clock()
    myfont = pygame.font.Font('algerian.ttf', 60)
    msg1 = myfont.render("You lost!", True, (BLACK), (None))
    msg1_box = msg1.get_rect()
    msg1_box.center = (scr.width/2, scr.height/4)
    msg2 = myfont.render("Click here to PLAY AGAIN!", True, (GREEN), (None))
    msg2_box = msg2.get_rect()
    msg2_box.center = (scr.width/2, 2 * scr.height/4)
    msg3 = myfont.render("Click here to EXIT!", True, (BLACK), (None))
    msg3_box = msg3.get_rect()
    msg3_box.center = (scr.width/2, 3 * scr.height/4)
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    sys.exit()
            if event.type == pygame.MOUSEBUTTONUP:
                if msg2_box.collidepoint(pygame.mouse.get_pos()):
                    main_game_loop(scr, window)
                if msg3_box.collidepoint(pygame.mouse.get_pos()):
                    sys.exit()
        window.fill(RED)
        window.blit(msg1, msg1_box)
        window.blit(msg2, msg2_box)
        window.blit(msg3, msg3_box)
        fpsClock.tick(120)
        pygame.display.update()


def success(scr, window):
    """
    Displaying information that you won the game.
    Enables to play again or exit the game.
    """
    pygame.init()
    fpsClock = pygame.time.Clock()
    myfont = pygame.font.Font('algerian.ttf', 60)
    msg1 = myfont.render("You won!", True, (BLACK), (None))
    msg1_box = msg1.get_rect()
    msg1_box.center = (scr.width/2, scr.height/4)
    msg2 = myfont.render("Click here to PLAY AGAIN!",
                         True, (RED), (None))
    msg2_box = msg2.get_rect()
    msg2_box.center = (scr.width/2, 2 * scr.height/4)
    msg3 = myfont.render("Click here to EXIT!",
                         True, (BLACK), (None))
    msg3_box = msg3.get_rect()
    msg3_box.center = (scr.width/2, 3 * scr.height/4)
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    sys.exit()
            if event.type == pygame.MOUSEBUTTONUP:
                if msg2_box.collidepoint(pygame.mouse.get_pos()):
                    main_game_loop(scr, window)
                if msg3_box.collidepoint(pygame.mouse.get_pos()):
                    sys.exit()
        window.fill(GREEN)
        window.blit(msg1, msg1_box)
        window.blit(msg2, msg2_box)
        window.blit(msg3, msg3_box)
        fpsClock.tick(120)
        pygame.display.update()


def missionaries_start(scr, missionaries):
    """
    Spawning missionaries on the beginning of the game.
    """
    for i, missionary in enumerate(missionaries):
        missionary["surf"] = pygame.image.load(missionary["file"])
        missionary["rect"] = missionary["surf"].get_rect()
        missionary["rect"].midleft = (scr.left, 470 + i*scr.height/12)
        missionary["coord"] = 470 + i*scr.height/12


def cannibals_start(scr, cannibals, missionaries):
    """
    Spawning cannibals on the beginning of the game.
    """
    for i, cannibal in enumerate(cannibals):
        cannibal["surf"] = pygame.image.load(cannibal["file"])
        cannibal["rect"] = cannibal["surf"].get_rect()
        cannibal["rect"].midleft = (scr.left, 470 +
                                    (i + len(missionaries))*scr.height/12)
        cannibal["coord"] = 470 + (i + len(missionaries))*scr.height/12


def boat_load(scr, missionaries, cannibals, boat, cursor_position):
    """
    Loading boat with passengers
    """
    for missionary in missionaries:
        if missionary["rect"].collidepoint(cursor_position):
            if not missionary["rect"].colliderect(boat["rect"]) \
                    and missionary["position"] == boat["position"]:
                if boat["capacity"] == 0:
                    missionary["rect"].midleft = boat["rect"].center
                    boat["capacity"] += 1
                    continue
                if boat["capacity"] == 1:
                    missionary["rect"].midright = boat["rect"].center
                    boat["capacity"] += 1
                    continue
                if boat["capacity"] == 2:
                    continue
    for cannibal in cannibals:
        if cannibal["rect"].collidepoint(cursor_position):
            if not cannibal["rect"].colliderect(boat["rect"]) \
                    and cannibal["position"] == boat["position"]:
                if boat["capacity"] == 0:
                    cannibal["rect"].midleft = boat["rect"].center
                    boat["capacity"] += 1
                    continue
                if boat["capacity"] == 1:
                    cannibal["rect"].midright = boat["rect"].center
                    boat["capacity"] += 1
                    continue
                if boat["capacity"] == 2:
                    continue


def boat_emptying(scr, missionaries, cannibals,
                  boat, cursor_position, emptying_btn):
    """
    Emptying the boat of passengers, when you want to
    change the characters that will be transported.
    """
    if emptying_btn["rect"].collidepoint(cursor_position):
        for missionary in missionaries:
            if missionary["rect"].colliderect(boat["rect"]):
                if boat["position"] == "left":
                    missionary["rect"].midleft = (scr.left,
                                                  missionary["coord"])
                else:
                    missionary["rect"].midright = (scr.right,
                                                   missionary["coord"])
        for cannibal in cannibals:
            if cannibal["rect"].colliderect(boat["rect"]):
                if boat["position"] == "left":
                    cannibal["rect"].midleft = (scr.left,
                                                cannibal["coord"])
                else:
                    cannibal["rect"].midright = (scr.right,
                                                 cannibal["coord"])
        boat["capacity"] = 0


def boat_ferry(scr, missionaries, cannibals, boat,
               cursor_position, key, gamestate, gamegraph, river):
    """
    Moving characters to the other bank of the river.
    """
    if boat["rect"].collidepoint(cursor_position):
        if boat["rect"].midleft == river.midleft:
            for missionary in missionaries:
                if missionary["rect"].colliderect(boat["rect"]):
                    missionary["rect"].midright = (scr.right,
                                                   missionary["coord"])
                    missionary["surf"] = (pygame.transform.flip
                                          (missionary["surf"], True, False))
                    boat["capacity"] -= 1
                    missionary["position"] = "right"
                    key = key + "m"
            for cannibal in cannibals:
                if cannibal["rect"].colliderect(boat["rect"]):
                    cannibal["rect"].midright = (
                                                (scr.right,
                                                 cannibal["coord"]))
                    cannibal["surf"] = (
                                        pygame.transform.flip
                                        (cannibal["surf"], True, False))
                    boat["capacity"] -= 1
                    cannibal["position"] = "right"
                    key = key + "c"
            boat["rect"].midright = river.midright
            boat["surf"] = pygame.transform.flip(boat["surf"], True, False)
            boat["position"] = "right"
            gamestate = gamegraph[gamestate][key]
        elif boat["rect"].midright == river.midright:
            for missionary in missionaries:
                if missionary["rect"].colliderect(boat["rect"]):
                    missionary["rect"].midleft = ((scr.left,
                                                  missionary["coord"]))
                    missionary["surf"] = (pygame.transform.
                                          flip(missionary["surf"],
                                               True, False))
                    boat["capacity"] -= 1
                    missionary["position"] = "left"
                    key = key + "m"
            for cannibal in cannibals:
                if cannibal["rect"].colliderect(boat["rect"]):
                    cannibal["rect"].midleft = (
                                                (scr.left,
                                                 cannibal["coord"]))
                    cannibal["surf"] = (
                                        pygame.transform.flip(cannibal["surf"],
                                                              True, False))
                    boat["capacity"] -= 1
                    cannibal["position"] = "left"
                    key = key + "c"
            boat["rect"].midleft = river.midleft
            boat["surf"] = pygame.transform.flip(boat["surf"], True, False)
            boat["position"] = "left"
            gamestate = gamegraph[gamestate][key]
    return gamestate


def main_game_loop(scr, window):
    """
    Main game loop. Gamestate graph definition.
    """
    pygame.init()
    background = pygame.image.load("bg.png").convert()
    fpsClock = pygame.time.Clock()

    river = pygame.Rect(200, 700, 500, 200)
    river.midbottom = scr.midbottom

    gamegraph = {
                 "mmmcccb-": {"m": "mmccc-bm", "mm": "mccc-bmm",
                              "c": "mmmcc-bc", "mc": "mmcc-bmc",
                              "cc": "mmmc-bcc"},
                 "mmmcc-bc": {"c": "mmmcccb-"},
                 "mmcc-bmc": {"mc": "mmmcccb-", "c": "mmcccb-m",
                              "m": "mmmccb-c"},
                 "mmmc-bcc": {"cc": "mmmcccb-", "c": "mmmccb-c"},
                 "mmmccb-c": {"c": "mmmc-bcc", "m": "mmcc-bmc",
                              "cc": "mmm-bccc", "mc": "mmc-bmcc",
                              "mm": "mcc-bmmc"},
                 "mmm-bccc": {"cc": "mmmccb-c", "c": "mmmcb-cc"},
                 "mmmcb-cc": {"m": "mmc-bmcc",
                              "mc": "mm-bmccc", "mm": "mc-bmmcc",
                              "c": "mmm-bccc"},
                 "mc-bmmcc": {"mm": "mmmcb-cc", "cc": "mcccb-mm",
                              "c": "mccb-mmc", "m": "mmcb-mcc",
                              "mc": "mmccb-mc"},
                 "mmccb-mc": {"mc": "mc-bmmcc", "c": "mmc-bmcc",
                              "cc": "mm-bmccc", "m": "mcc-bmmc",
                              "mm": "cc-bmmmc"},
                 "cc-bmmmc": {"mm": "mmccb-mc", "m": "mccb-mmc",
                              "mc": "mcccb-mm", "c": "cccb-mmm"},
                 "cccb-mmm": {"c": "cc-bmmmc", "cc": "c-bmmmcc"},
                 "c-bmmmcc": {"cc": "cccb-mmm",
                              "mm": "mmcb-mcc",
                              "m": "mcb-mmcc",
                              "c": "ccb-mmmc"},
                 "mcb-mmcc": {"m": "c-bmmmcc", "mc": "-bmmmccc"},
                 "ccb-mmmc": {"c": "c-bmmmcc", "cc": "-bmmmccc"},
                 "mmccc-bm": "failure",
                 "mmcccb-m": "failure",
                 "mccc-bmm": "failure",
                 "mcc-bmmc": "failure",
                 "mmc-bmcc": "failure",
                 "mccb-mmc": "failure",
                 "mm-bmccc": "failure",
                 "mcccb-mm": "failure",
                 "mccb-mcc": "failure",
                 "mmc-bmcc": "failure",
                 "-bmmmccc": "success",
                 }

    emptying_btn = {"file": "emptying.png"}
    boat = {"file": "boat.png", "position": "left", "capacity": 0}
    missionary1 = {"file": "missionary.png", "position": "left"}
    missionary2 = {"file": "missionary.png", "position": "left"}
    missionary3 = {"file": "missionary.png", "position": "left"}
    cannibal1 = {"file": "cannibal.png", "position": "left"}
    cannibal2 = {"file": "cannibal.png", "position": "left"}
    cannibal3 = {"file": "cannibal.png", "position": "left"}
    missionaries = [missionary1, missionary2, missionary3]
    cannibals = [cannibal1, cannibal2, cannibal3]

    missionaries_start(scr, missionaries)
    cannibals_start(scr, cannibals, missionaries)
    boat["surf"] = pygame.image.load(boat["file"])
    boat["rect"] = boat["surf"].get_rect()
    boat["rect"].midleft = river.midleft
    emptying_btn["surf"] = pygame.image.load(emptying_btn["file"])
    emptying_btn["rect"] = emptying_btn["surf"].get_rect()
    emptying_btn["rect"].midtop = (scr.width/2, scr.height/10)
    gamestate = "mmmcccb-"
    key = ""
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    sys.exit()
            if event.type == pygame.MOUSEBUTTONUP:
                boat_load(scr, missionaries,
                          cannibals, boat, pygame.mouse.get_pos())
                boat_emptying(scr, missionaries,
                              cannibals, boat,
                              pygame.mouse.get_pos(), emptying_btn)
                if boat["capacity"] != 0:
                    gamestate = (
                                boat_ferry(scr, missionaries,
                                           cannibals, boat,
                                           pygame.mouse.get_pos(),
                                           key, gamestate, gamegraph,
                                           river))
                if gamegraph[gamestate] == "failure":
                    failure(scr, window)
                elif gamegraph[gamestate] == "success":
                    success(scr, window)
                else:
                    key = ""
                    continue
        window.blit(background, [0, 0])
        window.blit(boat["surf"], boat["rect"])
        for missionary in missionaries:
            window.blit(missionary["surf"], missionary["rect"])
        for cannibal in cannibals:
            window.blit(cannibal["surf"], cannibal["rect"])
        window.blit(emptying_btn["surf"], emptying_btn["rect"])

        pygame.display.flip()
        fpsClock.tick(120)


def main():
    """
    Main part of program running the whole game.
    """
    pygame.init()
    fpsClock = pygame.time.Clock()

    while True:
        for event in pygame.event.get():
            menu()
    pygame.display.update()
    fpsClock.tick(120)


if __name__ == "__main__":
    """
    Starting the game
    """
    main()
