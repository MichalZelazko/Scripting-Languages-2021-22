import pygame
import sys


def rules_controls(scr, win, back_btn):
    """
    Displaying rules and controls of the game.
    Click BACK to get back to main menu.
    """
    pygame.init()
    fpsClock = pygame.time.Clock()
    myfont = pygame.font.Font('bauhs93.ttf', 24)
    myfontbig = pygame.font.Font('bauhs93.ttf', 50)
    controls = myfontbig.render("CONTROLS", True, (BLACK), (None))
    controls_box = controls.get_rect()
    controls_box.center = (scr.width/2, scr.height/12)
    ctrl1 = myfont.render("1. Line indicates the direction " +
                          "and the strength of a shot",
                          True, (BLACK), (None))
    ctrl1_box = ctrl1.get_rect()
    ctrl1_box.center = (scr.width/2, 2 * scr.height/12)
    ctrl2 = myfont.render("2. Click to shoot",
                          True, (BLACK), (None))
    ctrl2_box = ctrl2.get_rect()
    ctrl2_box.center = (scr.width/2, 3 * scr.height/12)
    rules = myfontbig.render("RULES", True, (BLACK), (None))
    rules_box = rules.get_rect()
    rules_box.center = (scr.width/2, 4 * scr.height/12)
    rule1 = myfont.render("1. The goal of the game is to " +
                          "put the ball in the hole",
                          True, (BLACK), (None))
    rule1_box = rule1.get_rect()
    rule1_box.center = (scr.width/2, 5 * scr.height/12)
    rule2 = myfont.render("2. Each level has a number of shots" +
                          " in which you", True, (BLACK), (None))
    rule2_box = rule2.get_rect()
    rule2_box.center = (scr.width/2, 6 * scr.height/12)
    rule2b = myfont.render("are supposed to finish the level," +
                           " called Par", True, (BLACK), (None))
    rule2b_box = rule2b.get_rect()
    rule2b_box.midtop = rule2_box.midbottom
    rule3 = myfont.render("3. Green field is grass - default surface",
                          True, (BLACK), (None))
    rule3_box = rule3.get_rect()
    rule3_box.center = (scr.width/2, 7.5 * scr.height/12)
    rule4 = myfont.render("Blue field is water - if the ball gets there,",
                          True, (BLACK), (None))
    rule4_box = rule4.get_rect()
    rule4_box.center = (scr.width/2, 8 * scr.height/12)
    rule4b = myfont.render("you have to start from the beginning",
                           True, (BLACK), (None))
    rule4b_box = rule4b.get_rect()
    rule4b_box.midtop = rule4_box.midbottom
    rule5 = myfont.render("Yellow field is sand - it slows the ball down",
                          True, (BLACK), (None))
    rule5_box = rule5.get_rect()
    rule5_box.center = (scr.width/2, 9 * scr.height/12)
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    sys.exit()
            if event.type == pygame.MOUSEBUTTONUP:
                if back_btn["rect"].collidepoint(pygame.mouse.get_pos()):
                    menu()
        win.fill(LIGHT_GREY)
        win.blit(back_btn["surf"], back_btn["rect"])
        win.blit(controls, controls_box)
        win.blit(ctrl1, ctrl1_box)
        win.blit(ctrl2, ctrl2_box)
        win.blit(rules, rules_box)
        win.blit(rule1, rule1_box)
        win.blit(rule2, rule2_box)
        win.blit(rule2b, rule2b_box)
        win.blit(rule3, rule3_box)
        win.blit(rule4, rule4_box)
        win.blit(rule4b, rule4b_box)
        win.blit(rule5, rule5_box)
        fpsClock.tick(240)
        pygame.display.update()


def level_choice(scr, win, back_btn, background):
    """
    Displaying rules and controls of the game.
    Click BACK to get back to main menu.
    """
    pygame.init()
    fpsClock = pygame.time.Clock()
    myfontbig = pygame.font.Font('bauhs93.ttf', 50)
    choice_text = myfontbig.render("CHOOSE THE LEVEL", True, (BLACK), (None))
    choice_text_box = choice_text.get_rect()
    choice_text_box.center = (scr.width/2, scr.height/12)

    level1_btn = {"file": "lvl1_button.png"}
    level2_btn = {"file": "lvl2_button.png"}
    level3_btn = {"file": "lvl3_button.png"}
    level4_btn = {"file": "lvl4_button.png"}
    level5_btn = {"file": "lvl5_button.png"}

    level_btns = [level1_btn, level2_btn, level3_btn, level4_btn, level5_btn]

    for i, btn in enumerate(level_btns):
        btn["surf"] = pygame.image.load(btn["file"])
        btn["rect"] = btn["surf"].get_rect()
        btn["rect"].center = ((i+1) * scr.width/6, scr.height/2)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    sys.exit()
            if event.type == pygame.MOUSEBUTTONUP:
                if back_btn["rect"].collidepoint(pygame.mouse.get_pos()):
                    menu()
                if level1_btn["rect"].collidepoint(pygame.mouse.get_pos()):
                    level1_build(scr, win, background, back_btn)
                if level2_btn["rect"].collidepoint(pygame.mouse.get_pos()):
                    level1_build(scr, win, background, back_btn)
                if level3_btn["rect"].collidepoint(pygame.mouse.get_pos()):
                    level3_build(scr, win, background, back_btn)
                if level4_btn["rect"].collidepoint(pygame.mouse.get_pos()):
                    level1_build(scr, win, background, back_btn)
                if level5_btn["rect"].collidepoint(pygame.mouse.get_pos()):
                    level1_build(scr, win, background, back_btn)
        win.fill(LIGHT_GREY)
        for btn in level_btns:
            win.blit(btn["surf"], btn["rect"])
        win.blit(back_btn["surf"], back_btn["rect"])
        win.blit(choice_text, choice_text_box)
        fpsClock.tick(240)
        pygame.display.update()


def success(scr, win, background, back_btn):
    """
    Displaying rules and controls of the game.
    Click BACK to get back to main menu.
    """
    global strokes
    pygame.init()
    fpsClock = pygame.time.Clock()
    myfontbig = pygame.font.Font('bauhs93.ttf', 50)
    winmsg = myfontbig.render(f'Nice! {strokes} strokes!',
                              True, BLACK, None)
    winmsg_box = winmsg.get_rect()
    winmsg_box.center = scr.center

    another_level_btn = {"file": "another_lvl_button.png"}
    exit_btn = {"file": "exit_button.png"}

    another_level_btn["surf"] = pygame.image.load(another_level_btn["file"])
    another_level_btn["rect"] = another_level_btn["surf"].get_rect()
    another_level_btn["rect"].center = 2.5 * scr.width/10, 8 * scr.height/10
    exit_btn["surf"] = pygame.image.load(exit_btn["file"])
    exit_btn["rect"] = exit_btn["surf"].get_rect()
    exit_btn["rect"].center = 7.5 * scr.width/10, 8 * scr.height/10

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    sys.exit()
            if event.type == pygame.MOUSEBUTTONUP:
                if another_level_btn["rect"].\
                   collidepoint(pygame.mouse.get_pos()):
                    strokes = 0
                    level_choice(scr, win, back_btn, background)
                if exit_btn["rect"].collidepoint(pygame.mouse.get_pos()):
                    sys.exit()
        win.fill(LIGHT_GREY)
        win.blit(winmsg, winmsg_box)
        win.blit(another_level_btn["surf"], another_level_btn["rect"])
        win.blit(exit_btn["surf"], exit_btn["rect"])
        fpsClock.tick(240)
        pygame.display.update()


def menu():
    """
    Main menu where a player can choose whether he wants to
    choose level to play the game, get to know rules and controls of the game
    or exit the game. Program responds when button is clicked.
    """
    win = pygame.display.set_mode((720, 720))
    scr = win.get_rect()
    fpsClock = pygame.time.Clock()
    background = pygame.image.load("grass.jpg")

    level_btn = {"file": "level_button.png"}
    rules_controls_btn = {"file": "rules_controls_button.png"}
    exit_btn = {"file": "exit_button.png"}
    back_btn = {"file": "back_button.png"}

    btns = [level_btn, rules_controls_btn, exit_btn]

    for i, btn in enumerate(btns):
        btn["surf"] = pygame.image.load(btn["file"])
        btn["rect"] = btn["surf"].get_rect()
        btn["rect"].center = (scr.width/2, (i + 2)*scr.height/5)

    back_btn["surf"] = pygame.image.load(back_btn["file"])
    back_btn["rect"] = back_btn["surf"].get_rect()
    back_btn["rect"].midbottom = (scr.width/2, scr.height - 20)

    myfontbig = pygame.font.Font('bauhs93.ttf', 60)
    header = myfontbig.render("MINIGOLF", True, (BLACK), (None))
    header_box = header.get_rect()
    header_box.center = (scr.width/2, scr.height/5)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    sys.exit()
            if event.type == pygame.MOUSEBUTTONUP:
                if level_btn["rect"].collidepoint(pygame.mouse.get_pos()):
                    level_choice(scr, win, back_btn, background)
                if rules_controls_btn["rect"].\
                   collidepoint(pygame.mouse.get_pos()):
                    rules_controls(scr, win, back_btn)
                if exit_btn["rect"].collidepoint(pygame.mouse.get_pos()):
                    sys.exit()
        win.blit(background, scr)
        win.blit(header, header_box)
        for btn in btns:
            win.blit(btn["surf"], btn["rect"])
        fpsClock.tick(240)
        pygame.display.update()


def level3_build(scr, win, background, back_btn):
    ball_speed = [0, 0]
    start_point = (500, 500)
    ball_pos = [start_point[0], start_point[1]]
    hole_pos = (100, 100)
    hole_flag = pygame.image.load("holeflag.png")
    hole_flag_box = hole_flag.get_rect()
    hole_flag_box.bottomright = hole_pos

    # (start_x, start_y, width, height)
    sand = [(230, 330, 100, 100), (300, 400, 50, 50)]
    waters = [(0, 200, 50, 300)]
    lwalls = [(150, 0, 30, 300), (400, 300, 30, 50)]
    rwalls = [(250, 0, 30, 330), (500, 300, 30, 80)]
    twalls = [(150, 300, 100, 30), (400, 300, 100, 30)]
    bwalls = [(150, 0, 100, 30), (400, 350, 100, 30)]

    while True:
        win.blit(background, scr)
        win.blit(hole_flag, hole_flag_box)
        pygame.time.delay(10)

        pygame.draw.circle(win, WHITE, hole_pos, HOLE_RADIUS)  # hole border
        pygame.draw.circle(win, BLACK, hole_pos, HOLE_RADIUS-1)  # hole

        # Drawing special areas and walls
        for area in sand:
            sandbox = pygame.draw.rect(win, SAND_YELLOW, area)
        if sandbox.collidepoint(ball_pos[0], ball_pos[1]):
            ball_speed[0] *= 0.9
            ball_speed[1] *= 0.9

        for area in waters:
            water = pygame.draw.rect(win, WATER_BLUE, area)
        if water.collidepoint(ball_pos[0], ball_pos[1]):
            ball_pos[0] = start_point[0]
            ball_speed[0] = 0
            ball_pos[1] = start_point[1]
            ball_speed[1] = 0

        for wall in lwalls:
            wall = pygame.draw.rect(win, LIGHT_GREY, wall)
            if wall.collidepoint(ball_pos[0] + BALL_RADIUS,
               ball_pos[1] + BALL_RADIUS):
                ball_speed[0] = -ball_speed[0]

        for wall in rwalls:
            wall = pygame.draw.rect(win, LIGHT_GREY, wall)
            if wall.collidepoint(ball_pos[0] - BALL_RADIUS,
               ball_pos[1] + BALL_RADIUS):
                ball_speed[0] = -ball_speed[0]

        for wall in twalls:
            wall = pygame.draw.rect(win, LIGHT_GREY, wall)
            if wall.collidepoint(ball_pos[0] + BALL_RADIUS,
               ball_pos[1] + BALL_RADIUS):
                ball_speed[1] = -ball_speed[1]

        for wall in bwalls:
            wall = pygame.draw.rect(win, LIGHT_GREY, wall)
            if wall.collidepoint(ball_pos[0] - BALL_RADIUS,
               ball_pos[1] - BALL_RADIUS):
                ball_speed[1] = -ball_speed[1]
        movement(win, scr, ball_pos, ball_speed,
                 hole_pos, back_btn, background)


def level1_build(scr, win, background, back_btn):
    ball_speed = [0, 0]
    start_point = (360, 700)
    ball_pos = [start_point[0], start_point[1]]
    hole_pos = (360, 100)
    hole_flag = pygame.image.load("holeflag.png")
    hole_flag_box = hole_flag.get_rect()
    hole_flag_box.bottomright = hole_pos

    # (start_x, start_y, width, height)
    lwalls = [(570, 400, 30, 60), (270, 400, 30, 60)]
    rwalls = [(150, 400, 30, 60), (450, 400, 30, 60)]
    twalls = [(0, 400, 150, 30), (570, 400, 150, 30), (300, 400, 150, 30)]
    bwalls = [(0, 430, 150, 30), (570, 430, 150, 30), (300, 430, 150, 30)]

    while True:
        win.blit(background, scr)
        win.blit(hole_flag, hole_flag_box)
        pygame.time.delay(10)

        pygame.draw.circle(win, WHITE, hole_pos, HOLE_RADIUS)  # hole border
        pygame.draw.circle(win, BLACK, hole_pos, HOLE_RADIUS-1)  # hole

        # Drawing walls
        for wall in lwalls:
            wall = pygame.draw.rect(win, LIGHT_GREY, wall)
            if wall.collidepoint(ball_pos[0] + BALL_RADIUS,
               ball_pos[1] + BALL_RADIUS):
                ball_speed[0] = -ball_speed[0]

        for wall in rwalls:
            wall = pygame.draw.rect(win, LIGHT_GREY, wall)
            if wall.collidepoint(ball_pos[0] - BALL_RADIUS,
               ball_pos[1] + BALL_RADIUS):
                ball_speed[0] = -ball_speed[0]

        for wall in twalls:
            wall = pygame.draw.rect(win, LIGHT_GREY, wall)
            if wall.collidepoint(ball_pos[0] + BALL_RADIUS,
               ball_pos[1] + BALL_RADIUS):
                ball_speed[1] = -ball_speed[1]

        for wall in bwalls:
            wall = pygame.draw.rect(win, LIGHT_GREY, wall)
            if wall.collidepoint(ball_pos[0] - BALL_RADIUS,
               ball_pos[1] - BALL_RADIUS):
                ball_speed[1] = -ball_speed[1]
        movement(win, scr, ball_pos, ball_speed,
                 hole_pos, back_btn, background)


def movement(win, scr, ball_pos, ball_speed,
             hole_pos, back_btn, background):
    global strokes
    pos = pygame.mouse.get_pos()
    ball = pygame.draw.circle(win, WHITE, (round(ball_pos[0]),
                              round(ball_pos[1])), BALL_RADIUS)

    if abs(ball_speed[0]) < 0.05 and abs(ball_speed[1]) < 0.05:
        pygame.draw.line(win, RED, (ball_pos[0], ball_pos[1]), pos)

    for event in pygame.event.get():
        if event.type == pygame.MOUSEBUTTONUP:
            ball_speed[0] = int((pos[0]-ball_pos[0])/SPEED_COEFFICIENT)
            ball_speed[1] = int((pos[1]-ball_pos[1])/SPEED_COEFFICIENT)
            strokes += 1
        if event.type == pygame.QUIT:
            sys.exit()
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                sys.exit()

    ball_pos[0] += ball_speed[0]
    ball_pos[1] += ball_speed[1]

    ball_speed[0] = ball_speed[0]*0.98  # Decceleration due to frictions
    ball_speed[1] = ball_speed[1]*0.98

    if ball_pos[0] > scr.bottom - BALL_RADIUS or ball_pos[0] \
       < scr.top + BALL_RADIUS:  # Bouncing
        ball_speed[0] *= -1
    if ball_pos[1] > scr.right - BALL_RADIUS or ball_pos[1] \
       < scr.left + BALL_RADIUS:
        ball_speed[1] *= -1

    if ((ball_pos[0] - hole_pos[0]) ** 2  # Checks to see if in hole
       + (ball_pos[1] - hole_pos[1]) ** 2)\
       ** 0.5 < HOLE_RADIUS:
        if abs(ball_speed[1]) < 0.2 and abs(ball_speed[0]) < 0.2:
            ball_speed = [0, 0]
            pygame.time.wait(500)
            success(scr, win, background, back_btn)
    pygame.display.update()
    return strokes


def main():
    """
    Main part of program running the whole game.
    """
    pygame.init()
    fpsClock = pygame.time.Clock()
    menu()


if __name__ == "__main__":
    """
    Starting the game
    """
    strokes = 0
    RED = (255, 0, 0)
    GREEN = (0, 255, 0)
    BLACK = (0, 0, 0)
    WHITE = (255, 255, 255)
    LIGHT_GREY = (192, 192, 192)
    SAND_YELLOW = (212, 176, 106)
    WATER_BLUE = (54, 84, 217)
    HOLE_RADIUS = 25
    BALL_RADIUS = 15
    SPEED_COEFFICIENT = 20
    main()
